"use client"

import { useState } from "react"
import { BroadcastHeader } from "@/components/broadcast-header"
import { BroadcastNavSidebar } from "@/components/broadcast-nav-sidebar"
import { BroadcastTable, type Broadcast } from "@/components/broadcast-table"
import { ChatBot } from "@/components/chat-bot"
import { BroadcastActionBar } from "@/components/broadcast-action-bar"
import { BroadcastFilterDrawer } from "@/components/broadcast-filter-drawer"

const broadcasts: Broadcast[] = [
  {
    id: "128471",
    title: "Varsity Football: Lincoln High vs. Central High",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Live",
    source: "Stadium Camera",
    date: "Oct 28, 2023",
    time: "7:30 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128471.png",
    prerollVideo: "preroll-128471.mp4",
    payPerViewEnabled: true,
    viewCount: 3245,
    errorMessage: "",
    sport: "Football",
    networkId: "NET-001",
    description: "Varsity Football Game",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "5 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128472",
    title: "Girls Varsity Volleyball Tournament",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Upcoming",
    source: "Hudl App",
    date: "Oct 29, 2023",
    time: "6:00 PM",
    privacy: "Public",
    payPerViewEnabled: false,
    viewCount: 0,
    errorMessage: "",
    sport: "Volleyball",
    networkId: "NET-001",
    description: "Volleyball District Tournament",
    level: "Varsity",
    resolution: "720p",
    bitrate: "3 Mbps",
    enableComments: true,
    allowDownload: false,
  },
  {
    id: "128473",
    title: "Boys Soccer - Varsity Match",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Upcoming",
    source: "Production Truck",
    date: "Oct 30, 2023",
    time: "3:30 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128473.png",
    payPerViewEnabled: false,
    viewCount: 0,
    errorMessage: "",
    sport: "Soccer",
    networkId: "NET-001",
    description: "Boys Varsity Soccer Match",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "4 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128456",
    title: "Varsity Basketball - Championship Game",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Stadium Camera",
    date: "Oct 27, 2023",
    time: "6:00 PM",
    privacy: "Public",
    prerollVideo: "preroll-128461.mp4",
    payPerViewEnabled: true,
    viewCount: 4102,
    errorMessage: "",
    sport: "Basketball",
    networkId: "NET-001",
    description: "Varsity Basketball Championship",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "5 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128457",
    title: "JV Volleyball - Conference Match",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "RTMP",
    date: "Oct 26, 2023",
    time: "5:00 PM",
    privacy: "No Scout",
    prerollVideo: "preroll-128459.mp4",
    payPerViewEnabled: true,
    viewCount: 2345,
    errorMessage: "",
    sport: "Volleyball",
    networkId: "NET-001",
    description: "JV Volleyball Conference Match",
    level: "JV",
    resolution: "720p",
    bitrate: "3 Mbps",
    enableComments: false,
    allowDownload: false,
  },
  {
    id: "128458",
    title: "Swimming - Regional Meet",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Hudl App",
    date: "Oct 25, 2023",
    time: "2:00 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128458.png",
    payPerViewEnabled: false,
    viewCount: 1834,
    errorMessage: "",
    sport: "Swimming",
    networkId: "NET-001",
    description: "Swimming Regional Meet",
    level: "Varsity",
    resolution: "720p",
    bitrate: "3 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128459",
    title: "Cross Country Championship",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Hudl App",
    date: "Oct 24, 2023",
    time: "9:00 AM",
    privacy: "Public",
    thumbnail: "thumbnail-128460.png",
    payPerViewEnabled: false,
    viewCount: 1203,
    errorMessage: "",
    sport: "Cross Country",
    networkId: "NET-001",
    description: "Cross Country Championship",
    level: "Varsity",
    resolution: "720p",
    bitrate: "2 Mbps",
    enableComments: true,
    allowDownload: false,
  },
  {
    id: "128460",
    title: "Baseball - Spring Training",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Error",
    source: "Production Truck",
    date: "Oct 28, 2023",
    time: "4:00 PM",
    privacy: "Public",
    payPerViewEnabled: false,
    viewCount: 234,
    errorMessage: "You have not started the Livestream in Production Truck",
    sport: "Baseball",
    networkId: "NET-001",
    description: "Baseball Spring Training",
    level: "JV",
    resolution: "1080p",
    bitrate: "4 Mbps",
    enableComments: true,
    allowDownload: false,
  },
  {
    id: "128461",
    title: "Tennis Tournament - Finals",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Error",
    source: "Stadium Camera",
    date: "Oct 29, 2023",
    time: "1:00 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128469.png",
    payPerViewEnabled: true,
    viewCount: 0,
    errorMessage: "Your Network connection at the venue is too poor",
    sport: "Tennis",
    networkId: "NET-001",
    description: "Tennis Tournament Finals",
    level: "Varsity",
    resolution: "720p",
    bitrate: "3 Mbps",
    enableComments: false,
    allowDownload: true,
  },
  {
    id: "128462",
    title: "Wrestling - Dual Meet",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Hudl App",
    date: "Oct 21, 2023",
    time: "7:00 PM",
    privacy: "No Scout",
    thumbnail: "thumbnail-128463.png",
    payPerViewEnabled: true,
    viewCount: 892,
    errorMessage: "",
    sport: "Wrestling",
    networkId: "NET-001",
    description: "Wrestling Dual Meet",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "4 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128463",
    title: "Cheer Competition",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "RTMP",
    date: "Oct 20, 2023",
    time: "10:00 AM",
    privacy: "Public",
    prerollVideo: "preroll-128464.mp4",
    payPerViewEnabled: true,
    viewCount: 5678,
    errorMessage: "",
    sport: "Cheer",
    networkId: "NET-001",
    description: "Cheer Competition",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "5 Mbps",
    enableComments: true,
    allowDownload: true,
  },
  {
    id: "128464",
    title: "Lacrosse Championship",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Stadium Camera",
    date: "Oct 19, 2023",
    time: "5:30 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128465.png",
    payPerViewEnabled: false,
    viewCount: 3456,
    errorMessage: "",
    sport: "Lacrosse",
    networkId: "NET-001",
    description: "Lacrosse Championship",
    level: "Varsity",
    resolution: "1080p",
    bitrate: "4 Mbps",
    enableComments: true,
    allowDownload: false,
  },
  {
    id: "128465",
    title: "Field Hockey - Semi-Finals",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Production Truck",
    date: "Oct 18, 2023",
    time: "3:45 PM",
    privacy: "Private",
    payPerViewEnabled: false,
    viewCount: 456,
    errorMessage: "",
    sport: "Field Hockey",
    networkId: "NET-001",
    description: "Field Hockey Semi-Finals",
    level: "Varsity",
    resolution: "720p",
    bitrate: "3 Mbps",
    enableComments: false,
    allowDownload: true,
  },
  {
    id: "128466",
    title: "Freshman Volleyball",
    site: "Lincoln High School",
    customer: "Lincoln High School",
    status: "Finished",
    source: "Hudl App",
    date: "Oct 17, 2023",
    time: "4:00 PM",
    privacy: "Public",
    thumbnail: "thumbnail-128467.png",
    payPerViewEnabled: false,
    viewCount: 234,
    errorMessage: "",
    sport: "Volleyball",
    networkId: "NET-001",
    description: "Freshman Volleyball Match",
    level: "Freshman",
    resolution: "720p",
    bitrate: "2.5 Mbps",
    enableComments: true,
    allowDownload: false,
  },
]

export default function Page() {
  const [filterOpen, setFilterOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("livestreams")

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <BroadcastNavSidebar activeTab={activeTab} onTabChange={setActiveTab} />
      <BroadcastHeader activeTab={activeTab} />

      {activeTab === "livestreams" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <BroadcastActionBar
            filterOpen={filterOpen}
            onToggleFilter={() => setFilterOpen((prev) => !prev)}
          />

          {filterOpen && <BroadcastFilterDrawer />}

          <BroadcastTable broadcasts={broadcasts} />
        </main>
      )}

      {activeTab === "analytics" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-foreground mb-8">Livestream Analytics</h2>
            
            <div className="grid gap-6 mb-8 md:grid-cols-4">
              <div className="rounded-lg bg-secondary p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Total Views</p>
                <p className="mt-3 text-3xl font-bold text-primary">18,645</p>
                <p className="text-xs text-muted-foreground mt-2">+12% from last month</p>
              </div>
              <div className="rounded-lg bg-secondary p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Unique Viewers</p>
                <p className="mt-3 text-3xl font-bold text-primary">12,120</p>
                <p className="text-xs text-muted-foreground mt-2">+8% from last month</p>
              </div>
              <div className="rounded-lg bg-secondary p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Avg. Duration</p>
                <p className="mt-3 text-3xl font-bold text-primary">42 min</p>
                <p className="text-xs text-muted-foreground mt-2">-3% from last month</p>
              </div>
              <div className="rounded-lg bg-secondary p-4">
                <p className="text-xs font-semibold uppercase text-muted-foreground">Revenue</p>
                <p className="mt-3 text-3xl font-bold text-primary">$3,420</p>
                <p className="text-xs text-muted-foreground mt-2">+24% from last month</p>
              </div>
            </div>

            <div className="border-t border-border pt-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Viewership by Sport</h3>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="rounded-lg border border-border p-4 bg-secondary/30">
                  <p className="text-sm font-semibold text-foreground mb-4">Views by Sport</p>
                  <div className="space-y-3">
                    {[
                      { sport: "Football", views: 4234, percentage: 23 },
                      { sport: "Basketball", views: 3891, percentage: 21 },
                      { sport: "Volleyball", views: 2567, percentage: 14 },
                      { sport: "Soccer", views: 2145, percentage: 12 },
                      { sport: "Other Sports", views: 5808, percentage: 30 },
                    ].map((item) => (
                      <div key={item.sport}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-foreground">{item.sport}</span>
                          <span className="text-xs font-semibold text-muted-foreground">{item.views.toLocaleString()}</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-border overflow-hidden">
                          <div
                            className="h-full bg-primary transition-all"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-lg border border-border p-4 bg-secondary/30">
                  <p className="text-sm font-semibold text-foreground mb-4">Views by Level</p>
                  <div className="space-y-3">
                    {[
                      { level: "Varsity", views: 10234, percentage: 55 },
                      { level: "JV", views: 6891, percentage: 37 },
                      { level: "Freshman", views: 1520, percentage: 8 },
                    ].map((item) => (
                      <div key={item.level}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-foreground">{item.level}</span>
                          <span className="text-xs font-semibold text-muted-foreground">{item.views.toLocaleString()}</span>
                        </div>
                        <div className="w-full h-2 rounded-full bg-border overflow-hidden">
                          <div
                            className="h-full bg-primary transition-all"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-border pt-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Top Teams by Viewership</h3>
              <div className="space-y-3">
                {[
                  { team: "West High School", views: 3456, trend: "↑ 12%" },
                  { team: "Central High School", views: 2891, trend: "↑ 8%" },
                  { team: "Jefferson High School", views: 2345, trend: "↓ 3%" },
                  { team: "Roosevelt High School", views: 1987, trend: "↑ 15%" },
                  { team: "Washington High School", views: 1654, trend: "→ 0%" },
                ].map((item) => (
                  <div key={item.team} className="flex items-center justify-between p-3 rounded-lg border border-border bg-secondary/30 hover:bg-secondary transition-colors">
                    <span className="text-sm font-medium text-foreground">{item.team}</span>
                    <div className="flex items-center gap-4">
                      <span className="text-xs font-semibold text-muted-foreground">{item.views.toLocaleString()} views</span>
                      <span className={`text-xs font-semibold ${item.trend.startsWith('↑') ? 'text-emerald-600' : item.trend.startsWith('↓') ? 'text-red-600' : 'text-muted-foreground'}`}>
                        {item.trend}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      )}

      {activeTab === "users" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-bold text-foreground">Manage Users</h2>
                <p className="text-sm text-muted-foreground mt-1">Add site admins and team members to help manage your livestreams</p>
              </div>
              <button className="px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-semibold transition-colors">
                Add User
              </button>
            </div>

            <div className="border-t border-border pt-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Current Users</h3>
              <div className="space-y-3">
                {[
                  { name: "John Smith", email: "john@westHS.edu", role: "Site Admin" },
                  { name: "Sarah Johnson", email: "sarah@westHS.edu", role: "Contributor" },
                  { name: "Mike Davis", email: "mike@westHS.edu", role: "Viewer" },
                ].map((user) => (
                  <div key={user.email} className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/30">
                    <div>
                      <p className="font-semibold text-foreground">{user.name}</p>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <select className="px-3 py-2 rounded-lg border border-border bg-background text-foreground text-sm">
                        <option>Site Admin</option>
                        <option>Contributor</option>
                        <option>Viewer</option>
                      </select>
                      <button className="px-3 py-2 rounded-lg border border-border text-foreground hover:bg-secondary transition-colors text-sm">
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-border pt-8 mt-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">Add New User</h3>
              <p className="text-sm text-muted-foreground mb-6">Enter the user's full name and email address. They'll receive an invitation to join your organization.</p>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Full Name</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                    placeholder="Enter full name..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Email Address</label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                    placeholder="Enter email address..."
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">Role</label>
                  <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                    <option>Contributor</option>
                    <option>Site Admin</option>
                    <option>Viewer</option>
                  </select>
                </div>
                <button className="px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-semibold transition-colors">
                  Send Invitation
                </button>
              </div>
            </div>
          </div>
        </main>
      )}

      {activeTab === "production-truck" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-foreground mb-2">Production Truck</h2>
            <p className="text-sm text-muted-foreground mb-8">Download and manage the Hudl Production Truck application</p>

            <div className="grid gap-8">
              <div className="border-b border-border pb-8">
                <h3 className="text-lg font-semibold text-foreground mb-4">Download Production Truck</h3>
                <p className="text-sm text-muted-foreground mb-4">Production Truck is a professional streaming software for Mac. Download the latest version below.</p>
                
                <div className="bg-secondary rounded-lg p-6 mb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-foreground">Production Truck v3.2.1</p>
                      <p className="text-xs text-muted-foreground mt-1">Released October 15, 2023 • macOS 10.15+</p>
                    </div>
                    <button className="px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-semibold transition-colors">
                      Download for Mac
                    </button>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-foreground mb-6">Learn Production Truck</h3>
                <p className="text-sm text-muted-foreground mb-6">Complete our academy-style learning course to master Production Truck</p>
                
                <div className="space-y-3">
                  {[
                    { title: "Getting Started", duration: "15 min", progress: 100 },
                    { title: "Camera Setup & Configuration", duration: "22 min", progress: 100 },
                    { title: "Audio Setup", duration: "18 min", progress: 65 },
                    { title: "Creating Your First Livestream", duration: "25 min", progress: 0 },
                    { title: "Advanced Features", duration: "30 min", progress: 0 },
                  ].map((course, idx) => (
                    <div key={idx} className="p-4 rounded-lg border border-border hover:bg-secondary/30 transition-colors cursor-pointer">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{course.title}</p>
                          <div className="mt-2 h-2 rounded-full bg-secondary overflow-hidden">
                            <div
                              className="h-full bg-primary transition-all"
                              style={{ width: `${course.progress}%` }}
                            />
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">{course.progress}% complete • {course.duration}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      {activeTab === "fans" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <h2 className="text-3xl font-bold text-foreground mb-2">Fans Guide</h2>
            <p className="text-lg text-muted-foreground mb-8">Resources for Athletic Directors on how to direct fans to watch your content</p>

            <div className="space-y-8">
              <div className="border-b border-border pb-8">
                <h3 className="text-2xl font-semibold text-foreground mb-6">How Fans Can Watch Your Broadcasts</h3>
                <p className="text-muted-foreground mb-6">We understand you can't make every game. That's why all home games are livestreamed through Team1Sports (powered by Hudl TV), so fans can watch on any device.</p>
              </div>

              <div className="space-y-6">
                <div className="p-6 rounded-lg border border-border bg-secondary/30">
                  <div className="flex items-start gap-4">
                    <div className="text-3xl">🌐</div>
                    <div className="flex-1">
                      <h4 className="text-xl font-semibold text-foreground mb-3">On the Website</h4>
                      <ol className="space-y-2 text-muted-foreground text-sm">
                        <li><span className="font-semibold">1.</span> Navigate to <span className="font-mono bg-background px-2 py-1 rounded">Team1Sports.com</span></li>
                        <li><span className="font-semibold">2.</span> Select "High School Sports" from the dropdown menu</li>
                        <li><span className="font-semibold">3.</span> Select your state</li>
                        <li><span className="font-semibold">4.</span> Find your school in the Schools section (listed alphabetically)</li>
                        <li><span className="font-semibold">5.</span> Click your school to access live and past broadcasts</li>
                        <li><span className="font-semibold">6.</span> If a broadcast requires pay-per-view, you'll see a lock symbol. Click to purchase access.</li>
                      </ol>
                    </div>
                  </div>
                </div>

                <div className="p-6 rounded-lg border border-border bg-secondary/30">
                  <div className="flex items-start gap-4">
                    <div className="text-3xl">📱</div>
                    <div className="flex-1">
                      <h4 className="text-xl font-semibold text-foreground mb-3">On Mobile & TV Apps</h4>
                      <ol className="space-y-2 text-muted-foreground text-sm">
                        <li><span className="font-semibold">1.</span> Download the <span className="font-semibold">Team1Sports app</span> from the App Store</li>
                        <li><span className="font-semibold">2.</span> Available on: Roku, Amazon Fire TV, Apple TV, or Android TV</li>
                        <li><span className="font-semibold">3.</span> Select "High School" at the top of the screen</li>
                        <li><span className="font-semibold">4.</span> Select your state</li>
                        <li><span className="font-semibold">5.</span> Find your school under Schools or Affiliates section</li>
                        <li><span className="font-semibold">6.</span> Access upcoming and past broadcasts</li>
                        <li><span className="font-semibold">7.</span> Similar to the website, pay-per-view broadcasts will show a lock symbol</li>
                      </ol>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-2xl font-semibold text-foreground mb-6">What to Share with Your Fans</h3>
                <p className="text-muted-foreground mb-6">Use these resources to communicate with your fan base about how they can watch your games:</p>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="p-6 rounded-lg border border-border bg-background">
                    <h4 className="font-semibold text-foreground mb-3">Quick Link</h4>
                    <p className="text-sm text-muted-foreground mb-4">Direct fans to your school page:</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value="https://team1sports.com/schools/lincoln-high-school"
                        readOnly
                        className="flex-1 px-3 py-2 rounded border border-border bg-secondary text-foreground text-xs"
                      />
                      <button className="px-3 py-2 rounded bg-primary text-primary-foreground hover:bg-primary/90 transition-colors text-sm font-medium">
                        Copy
                      </button>
                    </div>
                  </div>

                  <div className="p-6 rounded-lg border border-border bg-background">
                    <h4 className="font-semibold text-foreground mb-3">Download Guide</h4>
                    <p className="text-sm text-muted-foreground mb-4">Share this fan guide with your community:</p>
                    <button className="w-full px-4 py-2 rounded bg-primary text-primary-foreground hover:bg-primary/90 transition-colors text-sm font-medium">
                      Download PDF Guide
                    </button>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-2xl font-semibold text-foreground mb-6">Important Tips for Athletic Directors</h3>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg border border-border">
                    <h5 className="font-semibold text-foreground mb-2">Share Your Broadcast Schedule</h5>
                    <p className="text-sm text-muted-foreground">Update your school website and social media with upcoming game times so fans know when to tune in.</p>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <h5 className="font-semibold text-foreground mb-2">Promote Pay-Per-View Events</h5>
                    <p className="text-sm text-muted-foreground">Let your community know about special events that require pay-per-view access well in advance.</p>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <h5 className="font-semibold text-foreground mb-2">Encourage Mobile App Downloads</h5>
                    <p className="text-sm text-muted-foreground">Remind fans that the Team1Sports app provides the best viewing experience on TV, phones, and tablets.</p>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <h5 className="font-semibold text-foreground mb-2">Highlight Free vs. Paid Content</h5>
                    <p className="text-sm text-muted-foreground">Clearly communicate which games are free to watch and which require a pass, to avoid confusion at purchase time.</p>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <h5 className="font-semibold text-foreground mb-2">Monitor Viewer Engagement</h5>
                    <p className="text-sm text-muted-foreground">Use the Analytics tab to track how many fans are watching your broadcasts and adjust your promotion strategy accordingly.</p>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-2xl font-semibold text-foreground mb-6">Frequently Asked Questions</h3>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg border border-border">
                    <details>
                      <summary className="font-semibold text-foreground cursor-pointer hover:text-primary transition-colors">How do I create a pay-per-view pass?</summary>
                      <p className="text-sm text-muted-foreground mt-3">Visit the Pay-Per-View tab in the management console to set up event passes or season passes. You can configure pricing, access permissions, and which games are included.</p>
                    </details>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <details>
                      <summary className="font-semibold text-foreground cursor-pointer hover:text-primary transition-colors">Can fans watch broadcasts on multiple devices?</summary>
                      <p className="text-sm text-muted-foreground mt-3">Yes! Fans can watch on web browsers, smartphones, tablets, and streaming devices like Roku, Apple TV, Amazon Fire TV, and Android TV.</p>
                    </details>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <details>
                      <summary className="font-semibold text-foreground cursor-pointer hover:text-primary transition-colors">How long are broadcasts available after the game?</summary>
                      <p className="text-sm text-muted-foreground mt-3">Broadcasts remain available on-demand indefinitely (unless you choose to remove them). Fans can watch replays anytime.</p>
                    </details>
                  </div>

                  <div className="p-4 rounded-lg border border-border">
                    <details>
                      <summary className="font-semibold text-foreground cursor-pointer hover:text-primary transition-colors">Can I view statistics about who's watching?</summary>
                      <p className="text-sm text-muted-foreground mt-3">Yes! The Analytics tab shows viewer counts, watch time, device usage, and more to help you understand your audience.</p>
                    </details>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      {activeTab === "settings" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-foreground mb-8">Organization Settings</h2>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Organization Name
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                  placeholder="Enter your organization name..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Privacy Level
                </label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                  <option>Public</option>
                  <option>Private</option>
                  <option>No Scout</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Resolution
                </label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                  <option>1080p</option>
                  <option>720p</option>
                  <option>480p</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Bitrate
                </label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                  <option>Adaptive (Recommended)</option>
                  <option>High (5 Mbps)</option>
                  <option>Medium (2.5 Mbps)</option>
                  <option>Low (1 Mbps)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Streaming Source
                </label>
                <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                  <option>Stadium Camera</option>
                  <option>Hudl App</option>
                  <option>Production Truck</option>
                  <option>RTMP</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default PPV Price
                </label>
                <div className="flex items-center gap-2">
                  <span className="text-foreground">$</span>
                  <input
                    type="number"
                    className="flex-1 px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                    placeholder="9.99"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Enable PPV by Default
                </label>
                <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                  <button className="inline-flex h-6 w-10 items-center rounded-full bg-muted transition-colors">
                    <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-0.5" />
                  </button>
                  <span className="text-sm text-muted-foreground">Disabled</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Enable Comment Moderation by Default
                </label>
                <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                  <button className="inline-flex h-6 w-10 items-center rounded-full bg-primary transition-colors">
                    <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-4" />
                  </button>
                  <span className="text-sm text-muted-foreground">Enabled</span>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Network ID
                </label>
                <input
                  type="text"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                  placeholder="Enter network ID..."
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Thumbnail
                </label>
                <input
                  type="file"
                  accept="image/*"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Preroll Video
                </label>
                <input
                  type="file"
                  accept="video/*"
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-foreground mb-2">
                  Default Video Description
                </label>
                <textarea
                  className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                  rows={3}
                  placeholder="Enter default description..."
                />
              </div>
            </div>

            <div className="border-t border-border mt-8 pt-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Broadcast Display Settings</h3>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Enable Comments by Default
                  </label>
                  <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                    <button className="inline-flex h-6 w-10 items-center rounded-full bg-primary transition-colors">
                      <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-4" />
                    </button>
                    <span className="text-sm text-muted-foreground">Enabled</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Allow Downloads by Default
                  </label>
                  <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                    <button className="inline-flex h-6 w-10 items-center rounded-full bg-muted transition-colors">
                      <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-0.5" />
                    </button>
                    <span className="text-sm text-muted-foreground">Disabled</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Show Chat During Livestream
                  </label>
                  <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                    <button className="inline-flex h-6 w-10 items-center rounded-full bg-primary transition-colors">
                      <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-4" />
                    </button>
                    <span className="text-sm text-muted-foreground">Enabled</span>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Show Viewer Count
                  </label>
                  <div className="flex items-center gap-2 p-3 rounded-lg border border-border bg-background">
                    <button className="inline-flex h-6 w-10 items-center rounded-full bg-primary transition-colors">
                      <div className="inline-block h-5 w-5 transform rounded-full bg-white translate-x-4" />
                    </button>
                    <span className="text-sm text-muted-foreground">Enabled</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-border mt-8 pt-8">
              <h3 className="text-lg font-semibold text-foreground mb-6">Video Settings</h3>
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Default Watermark
                  </label>
                  <input
                    type="file"
                    accept="image/*"
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-foreground mb-2">
                    Default Channel
                  </label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                    placeholder="Enter channel name..."
                  />
                </div>
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button className="px-6 py-2 rounded-lg border border-border text-foreground hover:bg-secondary transition-colors font-semibold">
                Reset to Defaults
              </button>
              <button className="px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-semibold transition-colors">
                Save All Settings
              </button>
            </div>
          </div>
        </main>
      )}

      {activeTab === "ppv" && (
        <main className="ml-64 pt-40 space-y-6 p-6">
          <div className="rounded-xl border border-border bg-card p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-foreground mb-2">Pay-Per-View</h2>
            <p className="text-sm text-muted-foreground mb-8">Configure pay-per-view options for individual livestreams or create access passes for multiple livestreams, seasons, and groups.</p>
            
            <div className="space-y-8">
              <div className="border-t border-border pt-8">
                <h3 className="text-lg font-semibold text-foreground mb-6">Create PPV Event Pass</h3>
                <p className="text-sm text-muted-foreground mb-6">Set up a pay-per-view event for a single livestream. Viewers can pay once to access the livestream.</p>
                
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Event Price
                    </label>
                    <div className="flex items-center gap-2">
                      <span className="text-foreground">$</span>
                      <input
                        type="number"
                        className="flex-1 px-4 py-2 rounded-lg border border-border bg-background text-foreground"
                        placeholder="9.99"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Select Livestream
                    </label>
                    <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                      <option>Choose a livestream...</option>
                      <option>Varsity Football: West vs. East</option>
                      <option>Basketball: Varsity vs. City Rivals</option>
                      <option>Softball: Spring Training Game</option>
                    </select>
                  </div>
                </div>

                <div className="mt-6 space-y-4">
                  <p className="text-sm font-semibold text-foreground">What can viewers do with this livestream?</p>
                  <div className="space-y-3">
                    <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary cursor-pointer transition-colors">
                      <input type="checkbox" className="w-4 h-4" defaultChecked />
                      <div>
                        <p className="font-medium text-foreground">Watch Live</p>
                        <p className="text-xs text-muted-foreground">Viewers can watch the livestream live</p>
                      </div>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary cursor-pointer transition-colors">
                      <input type="checkbox" className="w-4 h-4" defaultChecked />
                      <div>
                        <p className="font-medium text-foreground">Watch On-Demand</p>
                        <p className="text-xs text-muted-foreground">Viewers can watch the event after it's archived</p>
                      </div>
                    </label>
                    <label className="flex items-center gap-3 p-3 rounded-lg border border-border hover:bg-secondary cursor-pointer transition-colors">
                      <input type="checkbox" className="w-4 h-4" />
                      <div>
                        <p className="font-medium text-foreground">Download</p>
                        <p className="text-xs text-muted-foreground">Viewers receive an .mp4 file to keep indefinitely</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="mt-6 p-4 rounded-lg bg-secondary">
                  <label className="flex items-center gap-3">
                    <input type="checkbox" className="w-4 h-4" defaultChecked />
                    <span className="text-sm font-medium text-foreground">Keep Single Use enabled (applies price to this livestream only)</span>
                  </label>
                </div>

                <button className="mt-6 px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 font-semibold transition-colors">
                  Create PPV Event Pass
                </button>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-lg font-semibold text-foreground mb-4">Access Passes</h3>
                <p className="text-sm text-muted-foreground mb-6">Create access passes that cover multiple livestreams, an entire season, a specific section, or a group of events.</p>
                <button className="px-6 py-2 rounded-lg border border-primary text-primary hover:bg-primary/5 font-semibold transition-colors">
                  Create Access Pass
                </button>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-lg font-semibold text-foreground mb-6">Active Passes</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-primary bg-primary/5">
                    <div>
                      <p className="font-semibold text-foreground">Fall Championship Series</p>
                      <p className="text-xs text-muted-foreground mt-1">$29.99 • 2,847 purchases • Expires Oct 31, 2024</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors">Edit</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors">Deactivate</button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 rounded-lg border border-primary bg-primary/5">
                    <div>
                      <p className="font-semibold text-foreground">Varsity Football Season Pass</p>
                      <p className="text-xs text-muted-foreground mt-1">$49.99 • 1,234 purchases • Expires Jan 15, 2024</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors">Edit</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors">Deactivate</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <h3 className="text-lg font-semibold text-foreground mb-6">Inactive Passes</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/30">
                    <div>
                      <p className="font-semibold text-foreground text-muted-foreground">Spring Sports Package</p>
                      <p className="text-xs text-muted-foreground mt-1">$39.99 • 856 purchases • Expired Mar 31, 2023</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">View Stats</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">Archive</button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/30">
                    <div>
                      <p className="font-semibold text-foreground text-muted-foreground">Summer Camp 2023</p>
                      <p className="text-xs text-muted-foreground mt-1">$19.99 • 445 purchases • Expired Aug 15, 2023</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">View Stats</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">Archive</button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/30">
                    <div>
                      <p className="font-semibold text-foreground text-muted-foreground">Winter Regional Tournament</p>
                      <p className="text-xs text-muted-foreground mt-1">$24.99 • 612 purchases • Expired Dec 22, 2022</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">View Stats</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">Archive</button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg border border-border bg-secondary/30">
                    <div>
                      <p className="font-semibold text-foreground text-muted-foreground">Playoff Championship</p>
                      <p className="text-xs text-muted-foreground mt-1">$34.99 • 1,089 purchases • Expired Nov 30, 2022</p>
                    </div>
                    <div className="flex gap-2">
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">View Stats</button>
                      <button className="px-3 py-1 rounded text-sm border border-border hover:bg-secondary transition-colors text-muted-foreground">Archive</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-border pt-8">
                <div className="grid gap-6 md:grid-cols-2">
                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Payment Provider
                    </label>
                    <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                      <option>Stripe</option>
                      <option>PayPal</option>
                      <option>Square</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-foreground mb-2">
                      Payout Method
                    </label>
                    <select className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground">
                      <option>Direct Bank Transfer</option>
                      <option>Check</option>
                      <option>PayPal</option>
                    </select>
                  </div>
                </div>

                <div className="mt-6 p-4 rounded-lg bg-secondary">
                  <div>
                    <p className="font-semibold text-foreground">Revenue Share Rate</p>
                    <p className="text-2xl font-bold text-primary mt-2">70% / 30%</p>
                    <p className="text-xs text-muted-foreground mt-1">You keep 70% of sales, Hudl keeps 30%</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      )}
      <ChatBot />
    </div>
  )
}
